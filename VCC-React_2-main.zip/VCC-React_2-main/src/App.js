import React from 'react';

const App = () => {
  const containerStyle = {
    padding: '40px',
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#f7f9fc',
    minHeight: '100vh',
    color: '#333'
  };

  const headerStyle = {
    textAlign: 'center',
    marginBottom: '40px'
  };

  const titleStyle = {
    fontSize: '36px',
    fontWeight: 'bold',
    color: '#2c3e50'
  };

  const descriptionStyle = {
    fontSize: '18px',
    marginTop: '10px',
    color: '#555'
  };

  const featuresStyle = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '30px',
    marginTop: '40px'
  };

  const featureBox = {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
  };

  const buttonStyle = {
    display: 'block',
    margin: '40px auto 0',
    padding: '12px 24px',
    backgroundColor: '#007bff',
    color: '#fff',
    borderRadius: '6px',
    fontSize: '16px',
    textDecoration: 'none',
    textAlign: 'center'
  };

  return (
    <div style={containerStyle}>
      <header style={headerStyle}>
        <h1 style={titleStyle}>Virtual Cloud Computing</h1>
        <p style={descriptionStyle}>
          Scalable, secure, and cost-effective cloud solutions tailored for your business.
        </p>
      </header>

      <section style={featuresStyle}>
        <div style={featureBox}>
          <h3>☁️ Instant Scalability</h3>
          <p>Automatically scale up or down based on your workload with zero downtime.</p>
        </div>
        <div style={featureBox}>
          <h3>🔐 Enterprise Security</h3>
          <p>Secure infrastructure with encryption, access control, and real-time monitoring.</p>
        </div>
        <div style={featureBox}>
          <h3>💰 Pay-as-You-Go</h3>
          <p>Only pay for what you use. No upfront costs or long-term commitments.</p>
        </div>
        <div style={featureBox}>
          <h3>🌍 Global Access</h3>
          <p>Deploy across multiple regions with high availability and low latency.</p>
        </div>
      </section>

      <a href="#" style={buttonStyle}>Get Started Free</a>
    </div>
  );
};

export default App;
